import setuptools

with open("README.md", "r") as fh:
    long_description = fh.read()

"""
 packages=setuptools.find_packages()
 -> list of packages needed in the package.
    find_packages() automatically finds all used packages.

 classifier: according to pypi classification scheme.
 https://pypi.org/classifiers/


"""
setuptools.setup(
    name="example-pkg-Hoseung",
    version="0.0.1",
    author="Hoesung Choi",
    author_email="hopung@gmail.com",
    description="Testing",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="github.com",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python 3",
        "License ::OSI Approved :: MIT License",
        "Operating System :: Linux"
    ],
    python_requires='>=3.7',
)